# ludo_offline
Offline ludo game developed in android studio

